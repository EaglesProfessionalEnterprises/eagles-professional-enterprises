# Eagles Professional Enterprises Website

A responsive static website for Eagles Professional Enterprises.

## Pages
- Home
- About Us
- Why Choose Us
- Debt Collection
- Auctioneering
- Building Materials & Hardware Supply
- Clearing & Forwarding
- Car Parking Services
- Gallery
- Contact

## Deploy
Upload the contents of this folder to the root of a GitHub repository. The entry page is `index.html`.

For Render, create a **Static Site** connected to this GitHub repository. No build command is required; use `.` as the publish directory.

## Important
- The original company logo supplied by the user is included unchanged at `assets/eagles-logo.jpg`.
- Contact details currently shown: eaglesprofessionalenterprises@gmail.com and P.O. Box 36359, Tegeta, Wazo, Mivumoni Street, Dar es Salaam, Tanzania.
- The gallery contains service placeholders until genuine company project photographs are supplied.
- The contact email button opens the visitor's email app; no server-side form processing is included.
